#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { \
    vertexDistance=length((ModelViewMat*vertex).xyz); \
    texCoord0=UV0; \
}

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_175a66db(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_ff0220bf() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_d48bf3c6(inout vec4 vertex) {
    f_175a66db(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_ff0220bf();
    }
    finalize();
}



void f_bd8c7991() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_c2c1eaa4() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_c1639462(inout vec4 vertex) {
    f_175a66db(vertex);
    f_bd8c7991();
    finalize();
}

void f_c7a6a7d0(inout vec4 vertex) {
    f_175a66db(vertex);
    f_ff0220bf();
    f_c2c1eaa4();
    finalize();
}

void f_578ea84c(inout vec4 vertex) {
    f_175a66db(vertex);
    f_c2c1eaa4();
    f_bd8c7991();
    finalize();
}

void f_d222d051(inout vec4 vertex) {
    f_ff0220bf();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_175a66db(vertex);
    finalize();
}

void f_e008a20e(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_bd8c7991();
    f_175a66db(vertex);
    finalize();
}

void f_fd420f19(inout vec4 vertex, float speed) {
    f_175a66db(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_646ff649(inout vec4 vertex) {
    f_175a66db(vertex);
    f_ff0220bf();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_d48bf3c6(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_ff0220bf();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_175a66db(vertex);
            f_ff0220bf();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_c7a6a7d0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_c7a6a7d0(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_d222d051(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_d222d051(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_fd420f19(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_646ff649(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_c1639462(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_c7a6a7d0(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_578ea84c(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_d222d051(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_e008a20e(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_fd420f19(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_c1639462(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_c7a6a7d0(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_578ea84c(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_d222d051(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_e008a20e(vertex);
        return;
    }
    

    
    f_175a66db(vertex);
    f_ff0220bf();
    finalize();
}